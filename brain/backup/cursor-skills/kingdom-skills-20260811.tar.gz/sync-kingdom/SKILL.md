---
name: sync-kingdom
description: >-
  Sync Avinash Kingdom panel data from venture STATUS, phases, and expenses.
  Use after editing STATUS.md, tracking/phases.json, tracking/expenses.jsonl, or
  when the user asks to sync Kingdom, refresh the command center, or update ventures.json.
---

# Sync Kingdom

## When

Run after any change to venture progress, phase gates, or expense logs that should appear in the Kingdom panel.

## Command

```bash
cd /Users/avinashnandyala/Projects/avinashs-kingdom && npm run sync
```

Report success/failure from the script output. Do not skip sync after phase PASS/FAIL or STATUS edits.

## Notes

- Panel seeds live under `public/data/`.
- Manual expense/token edits in the UI stay in browser localStorage; synced rows refresh on load.
- If sync fails because a path is missing, say which venture path broke — do not invent data.
